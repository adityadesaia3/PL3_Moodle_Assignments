import math.*;
import math.special.*;
import java.util.Scanner;

public class Calculate
{
	public static void main (String args[])
	{
		boolean flag1 = true;

		do
		{

			System.out.println("\n1. Math");
			System.out.println("2. Special");
			System.out.println("Enter any number other than above to EXIT.");
			System.out.println("\nEnter the choice: ");
			int choice1 = new Scanner(System.in).nextInt();
			if (choice1 < 1 || choice1 > 2)
				flag1 = false;

			if (choice1 == 1)
			{
				boolean flag2 = true;
				do 
				{
					System.out.println("\n1. Addition");
					System.out.println("2. Subtraction");
					System.out.println("3. Multiplication");
					System.out.println("4. Division");
					System.out.println("Enter any number other than above to go in PREVIOUS MENU.");
					System.out.println("\nEnter the choice: ");
					int choice2 = new Scanner(System.in).nextInt();
					System.out.println();

					if (choice2 < 1 || choice2 > 4)
						flag2 = false;

					if (choice2 == 1)
					{
						System.out.println("\nEnter the two numbers below.");
						double x1 = new Scanner(System.in).nextDouble();
						double x2 = new Scanner(System.in).nextDouble();

						Addition aObject = new Addition();
						System.out.println("\nAddition: " + aObject.add(x1, x2) + ".\n\n");
					}
					else if (choice2 == 2)
					{
						System.out.println("\nEnter the two numbers below.");
						double x1 = new Scanner(System.in).nextDouble();
						double x2 = new Scanner(System.in).nextDouble();

						Subtraction sObject = new Subtraction();
						System.out.println("\nSubtraction: " + sObject.subtract(x1, x2) + ".\n\n");
					}
					else if (choice2 == 3)
					{
						System.out.println("\nEnter the two numbers below.");
						double x1 = new Scanner(System.in).nextDouble();
						double x2 = new Scanner(System.in).nextDouble();

						Multiplication mObject = new Multiplication();
						System.out.println("\nMultiplication: " + mObject.multiply(x1, x2) + ".\n\n");
					}
					else if (choice2 == 4)
					{
						System.out.println("\nEnter the two numbers below.");
						double x1 = new Scanner(System.in).nextDouble();
						double x2 = new Scanner(System.in).nextDouble();

						Division dObject = new Division();
						System.out.println("\nDivision: " + dObject.divide(x1, x2) + ".\n\n");
					}
				}
				while (flag2);
			}
			else if (choice1 == 2)
			{
				boolean flag2 = true;

				do
				{
					System.out.println("\n1. Factorial");
					System.out.println("2. Fibonacci");
					System.out.println("3. Armstrong");
					System.out.println("4. EvenOdd");
					System.out.println("Enter any number other than above to go in PREVIOUS MENU.");
					System.out.println("\nEnter the choice: ");
					int choice2 = new Scanner(System.in).nextInt();
					System.out.println();

					if (choice2 < 1 || choice2 > 4)
						flag2 = false;

					if (choice2 == 1)
					{
						Factorial fObject = new Factorial();
						System.out.println("\nEnter the number less than 20 to find its Factorial.");
						long fNumber = new Scanner(System.in).nextLong();
						System.out.println("\nFactorial: " + fObject.calculateFactorial(fNumber) + ".\n\n");
					}
					else if (choice2 == 2)
					{
						Fibonacci fBObject = new Fibonacci();
						System.out.println("\nEnter the number to find its fibonacci series.");
						long fBNumber = new Scanner(System.in).nextLong();
						long fBSeries [] = new long[100000];
						int sizeFB [] = new int[1];

						fBSeries = fBObject.calculateFibonacciSeries(fBNumber, sizeFB);
						// Displaying Fibonacci Series
						System.out.println("\nFibonacci Series of " + fBNumber + ":");
						for (int i = 0; i < sizeFB[0]; i++)
						{
							System.out.print(fBSeries[i] + " ");
						}
						System.out.println("\n\n");
					}
					else if (choice2 == 3)
					{
						Armstrong armObject = new Armstrong();
						System.out.println("\nEnter the number to find Armstrong Numbers till it.");
						long armNumber = new Scanner(System.in).nextLong();
						long armSeries [] = new long[100];
						int sizeArm [] = new int[1];

						armSeries = armObject.findArmstrongNumbers(armNumber, sizeArm);
						// Displaying Armstrong Series
						System.out.println("\nArmstrong Numbers till " + armNumber + ":");
						for (int i = 0; i < sizeArm[0]; i++)
						{
							System.out.print(armSeries[i] + " ");
						}
						System.out.println("\n\n");
					}
					else if (choice2 == 4)
					{
						EvenOdd eoObject = new EvenOdd();
						System.out.println("\nEnter the below to check if it is EVEN or ODD.");
						long eoNumber = new Scanner(System.in).nextLong();

						// EvenOdd
						System.out.println("\nThe number " + eoNumber + " is " + eoObject.findEvenOdd(eoNumber)+ ".\n\n");
					}
				}
				while (flag2);
			}
		}
		while (flag1);
		
		return;
	}

}

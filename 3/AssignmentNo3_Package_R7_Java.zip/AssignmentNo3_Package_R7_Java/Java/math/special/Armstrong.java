package math.special;
// Optimize the program

public class Armstrong
{
	public long [] findArmstrongNumbers(long number, int [] size)
	{
		long armstrongArray [] = new long[100];
		int index = 0;
		
		for (long i = 0; i <= number; i++)
		{
			long totalSum = 0;
			long raiseTo = 0;
			long tempNumber = i;
			long checkSum = 0;
			long digit;
			
			while (tempNumber > 0)
			{
				tempNumber /= 10;
				raiseTo++;
			}
			
			tempNumber = i;
			while(tempNumber > 0)
			{
				digit = tempNumber % 10;
				
				// calculating power
				if (raiseTo == 0)
					checkSum = 1;
				else if (raiseTo == 1)
					checkSum = digit;
				else if (raiseTo > 1)
				{
					checkSum = digit;
					for (int j = 2; j <= raiseTo; j++)
					{
						checkSum *= digit;
					}
				} 
				totalSum += checkSum;
				tempNumber /= 10;	
			}
			
			if (i == totalSum)
				armstrongArray[index++] = i;
		}
		size[0] = index;
		return armstrongArray;
	}
}



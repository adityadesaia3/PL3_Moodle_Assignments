package math.special;

public class EvenOdd
{
	public String findEvenOdd(long number)
	{
		if ((number % 2) == 0)
			return "EVEN";
		else return "ODD";
	}
}
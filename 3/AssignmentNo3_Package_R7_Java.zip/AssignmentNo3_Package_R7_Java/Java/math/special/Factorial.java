package math.special;

public class Factorial
{
	public long calculateFactorial(long number)
	{
		long factorial = number;
		if (number == 0)
			return 1;
		while(number > 1)
		{
			number--;
			factorial *= number;	
		}
		return factorial;
	}
}


package math.special;
public class Fibonacci
{
	public long [] calculateFibonacciSeries(long number, int [] sizeFB)
	{
		long fibonaciiArray [] = new long[100000];
		int fAIndex = 0;
		long previousNumber = 0;
		long currentNumber = 1;
		long nextNumber = previousNumber + currentNumber;
		
		if (number > 0)
		{
			fibonaciiArray[fAIndex++] = previousNumber;
			fibonaciiArray[fAIndex++] = currentNumber;
			
			while (nextNumber <= number)
			{
				fibonaciiArray[fAIndex++] = nextNumber;
				previousNumber = currentNumber;
				currentNumber = nextNumber;
				nextNumber = currentNumber + previousNumber;
			}
		}
		else if (number == 0)
		{
			fibonaciiArray[fAIndex++] = previousNumber;
		}
		
		sizeFB[0] = fAIndex;
		
		return fibonaciiArray;
	}
 
}

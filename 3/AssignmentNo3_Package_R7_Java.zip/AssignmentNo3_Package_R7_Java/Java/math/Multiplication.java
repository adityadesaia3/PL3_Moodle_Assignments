package math;

public class Multiplication
{
	public double multiply(double x1, double x2)
	{
		return x1 * x2;
	}
}

package math;

public class Addition
{
	public double add(double x1, double x2)
	{
		return x1 + x2;
	}
}

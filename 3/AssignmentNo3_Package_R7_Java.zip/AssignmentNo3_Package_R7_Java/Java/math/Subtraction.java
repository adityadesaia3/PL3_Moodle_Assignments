package math;

public class Subtraction
{
	public double subtract(double x1, double x2)
	{
		return x1 - x2;
	}
}

package math;

public class Division
{
	public double divide(double x1, double x2)
	{
		return x1 / x2;
	}
}
